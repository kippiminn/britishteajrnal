# The British Tea Journal

Русскоязычный адаптивный исторический веб-журнал о чае и британской культуре.

## Запуск
Откройте `index.html` в браузере для просмотра. Для корректной работы PWA/offline режима запустите локальный сервер из этой папки:

```bash
python -m http.server 8000
```

Затем откройте `http://localhost:8000`.

## Структура
- `index.html` — главная редакционная обложка
- `history.html` — хронология и архивная гравюра
- `collection.html` — каталог музейных предметов с раскрывающимися карточками
- `geography.html` — интерактивная схематичная карта
- `traditions.html` — британские традиции
- `facts.html` — короткие факты
- `sources.html` — источники, примечания и права
- `assets/` — стили и интерактивность
- `sw.js`, `manifest.webmanifest` — базовая PWA-оболочка

## Офлайн
Service worker кэширует HTML, CSS, JavaScript и manifest. Изображения музейных коллекций загружаются с внешних серверов и требуют подключения к интернету при первом просмотре; они не гарантированно доступны офлайн. Google Fonts также загружаются извне, с системными шрифтами в качестве запасного варианта.

## Изображения и лицензии
1. Worcester teapot, c. 1765–75, The Metropolitan Museum of Art, объект 39.140.64a,b. Музей помечает изображение как Public Domain: https://www.metmuseum.org/art/collection/search/198459
2. Thomas Rowlandson, after Samuel Collings, *Tea at the Journalist's House in St. James's Court*, 15 May 1786, Metropolitan Museum of Art, 17.3.888-358. Файл через Wikimedia Commons, CC0: https://commons.wikimedia.org/wiki/File:Tea_at_the_Journalist%27s_House_in_St._James%27s_Court_(Picturesque_Beauties_of_Boswell,_Part_the_First)_MET_DP871882.jpg
3. Контекст гравюры и цитаты Сэмюэла Джонсона: Royal Collection Trust: https://www.rct.uk/collection/stories/tea-in-the-royal-collection/tea-at-the-journalists-house-in-jamess-court

## Важные редакционные оговорки
- Цитата Джонсона дана коротким фрагментом и сопровождается русским переводом.
- Карта географическая и схематичная, не точная карта торговых маршрутов.
- Исторические даты в шкале обозначают ориентиры процесса; ранние сведения о появлении чая в Англии требуют различать первые упоминания, импорт и распространение потребления.
- Сведения об Afternoon Tea и High Tea даны как общее историческое различие; точная история возникновения Afternoon Tea требует дальнейшего углублённого источниковедческого исследования.
- Этот проект не является полноценным академическим изданием; ссылки ведут к музейным и историческим источникам для проверки и дальнейшего чтения.
